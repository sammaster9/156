
public class Persons {

	private String personCode;
	private String name;
	private String personsAddress;
	private String street;
	private String city;
	private String state;
	private String zipCode;
	private String country;
	private String email;
	private String email2;
	private String emailAddress;
	


	public Persons(String personCode, String name, String street, 
			String city, String state, String zipCode, String country, 
			String email, String email2){
		this.personCode = personCode;
		this.name = name;
		this.street = street;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
		this.country = country;
		this.email = email;
		this.email2 = email2;
	}

	// getter for personCode
	public String getPersonCode(){
		return this.personCode;
	}

	// getter for name
	public String getName(){
		return this.name;
	}


	// getter for address
	public String getPersonsAddress(){
		return this.personsAddress;
	}


	//getter for emailAddress
	public String getEmailAddress(){
		return this.emailAddress;
	}
	

	public String getEmail() {
		return email;
	}

	public String getEmail2() {
		return email2;
	}

	public String getStreet() {
		return street;
	}

	public String getCity() {
		return city;
	}

	public String getState() {
		return state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public String getCountry() {
		return country;
	}




}
