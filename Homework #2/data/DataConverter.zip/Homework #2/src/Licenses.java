
public class Licenses {

	private String productCode;
	private String productType;
	private String productName;
	private double serviceFee;
	private double annualLicenseFee;

	Licenses(String productCode, String productType, String productName, double serviceFee, double annualLicenseFee){
		this.productCode = productCode;
		this.productType = productType;
		this.productName = productName;
		this.serviceFee = serviceFee;
		this.annualLicenseFee = annualLicenseFee;
	}

	// getter for productCode
	public String getProductCode(){
		return this.productCode;
	}

	//getter for productType
	public String getproductType(){
		return this.productType;
	}

	//getter for productName
	public String getProductName(){
		return this.productName;
	}

	//getter for serviceFee
	public double getServiceFee(){
		return this.serviceFee;
	}

	//getter for annualLicenceFee
	public double getAnnualLicenseFee(){
		return this.annualLicenseFee;
	}

}
