
public class Equipment {

	private String productCode;
	private String productType;
	private String productName;
	private double pricePerUnit;

	Equipment(String productCode, String productType, String productName, double pricePerUnit){
		this.productCode = productCode;
		this.productType = productType;
		this.productName = productName;
		this.pricePerUnit = pricePerUnit;
	}


	//getter for productCofde
	public String getProductCode(){
		return this.productCode;
	}

	//getter for productType
	public String getproductType(){
		return this.productType;
	}

	//getter for productName
	public String getProductName(){
		return this.productName;
	}

	//getter for pricePerUnit
	public double getPricePerUnit(){
		return this.pricePerUnit;
	}

}