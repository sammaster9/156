
public class Consultations {

	private String productCode;
	private String productType;
	private String productName;
	private String consultantPersonCode;
	private double hourlyFee;
	
	Consultations(String productCode, String productType, String productName, String consultantPersonCode, double hourlyFee){
		this.productCode = productCode;
		this.productType = productType;
		this.productName = productName;
		this.consultantPersonCode = consultantPersonCode;
		this.hourlyFee = hourlyFee;
	}
	
	// getter for productCode
		public String getProductCode(){
			return this.productCode;
		}
		
		//getter for productType
		public String getproductType(){
			return this.productType;
		}

		//getter for productName
		public String getProductName(){
			return this.productName;
		}
		
		//getter for privateConsultantCode
		public String getConsultantPersonCode(){
			return this.consultantPersonCode;
		}
		
		//getter for hourlyFee
		public double getHourlyFee(){
			return this.hourlyFee;
		}
		
}
